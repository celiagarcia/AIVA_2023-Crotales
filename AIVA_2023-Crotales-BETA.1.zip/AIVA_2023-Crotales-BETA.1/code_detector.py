'''
AIVA_2023-Crotales
@author: Rebeca Villarraso / Celia Garcia
'''
import cv2